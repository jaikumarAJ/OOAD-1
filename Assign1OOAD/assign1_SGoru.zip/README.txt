Name: Swathi Goru
Course Name: Object Oriented Analysis and Design (COEN275)
Assignment Number: 1

IDE used: Eclipse 4.6.0
Java version: JDK 1.8

Jar files are available in:
Assign1OOAD/jar

Jar file for Q1 - Assign1q1SwathiGoru.jar
Jar file for Q2 - Assign1q2SwathiGoru.jar

Question1's related files:
src/goru/assign1/q1
This folder contains
USMoney.java
USMoneyTester.java

Question'2 related files:
src/goru/assign1/q2
This folder contains
Q2TestCase.java

src/goru/assign1/salebin
This folder contains
Bin.java
SaleItem.java
SmartBin.java

Use the below command to execute jar files (for Mac):
java -jar Assign1q1SwathiGoru.jar

java -jar Assign1q2SwathiGoru.jar




